package fr.sup.galilee.pharmacymanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.sup.galilee.pharmacymanagement.entite.CartProduct;
import fr.sup.galilee.pharmacymanagement.repository.CartProductRepository;

@Service
public class CartProductService {

    private final CartProductRepository cartProductRepository;

    @Autowired
    public CartProductService(CartProductRepository cartProductRepository) {
        this.cartProductRepository = cartProductRepository;
    }

    public List<CartProduct> findCartProductsByCartId(Long cartId) {
        return cartProductRepository.findByCartId(cartId);
    }

    public CartProduct saveCartProduct(CartProduct cartProduct) {
        return cartProductRepository.save(cartProduct);
    }

    
}