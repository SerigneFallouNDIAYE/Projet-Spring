package fr.sup.galilee.pharmacymanagement.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.sup.galilee.pharmacymanagement.entite.Cart;
import fr.sup.galilee.pharmacymanagement.repository.CartRepository;

@Service
public class CartService {

    private final CartRepository cartRepository;

    @Autowired
    public CartService(CartRepository cartRepository) {
        this.cartRepository = cartRepository;
    }

    public Optional<Cart> findCartByUserId(Long userId) {
        return cartRepository.findById(userId);
    }

    public Cart saveCart(Cart cart) {
        return cartRepository.save(cart);
    }

   
}