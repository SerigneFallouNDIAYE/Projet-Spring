package fr.sup.galilee.pharmacymanagement.DTO;


	import java.util.List;
	public class CartDTO {

	    private Long id;
	    private UserDTO user;
	    private List<CartProductDTO> cartProducts;

	    public CartDTO() {
	    }

	    public CartDTO(Long id, UserDTO user, List<CartProductDTO> cartProducts) {
	        this.id = id;
	        this.user = user;
	        this.cartProducts = cartProducts;
	    }

	    // Getters and Setters
	    public Long getId() {
	        return id;
	    }

	    public void setId(Long id) {
	        this.id = id;
	    }

	    public UserDTO getUser() {
	        return user;
	    }

	    public void setUser(UserDTO user) {
	        this.user = user;
	    }

	    public List<CartProductDTO> getCartProducts() {
	        return cartProducts;
	    }

	    public void setCartProducts(List<CartProductDTO> cartProducts) {
	        this.cartProducts = cartProducts;
	    }
	}
