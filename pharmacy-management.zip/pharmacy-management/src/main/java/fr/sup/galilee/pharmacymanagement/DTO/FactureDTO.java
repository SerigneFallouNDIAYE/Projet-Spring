package fr.sup.galilee.pharmacymanagement.DTO;

public class FactureDTO {

	    private Long id;
	    private UserDTO user;
	    private Double total;

	    public FactureDTO() {
	    }

	    public FactureDTO(Long id, UserDTO user, Double total) {
	        this.id = id;
	        this.user = user;
	        this.total = total;
	    }

	    // Getters and Setters
	    public Long getId() {
	        return id;
	    }

	    public void setId(Long id) {
	        this.id = id;
	    }

	    public UserDTO getUser() {
	        return user;
	    }

	    public void setUser(UserDTO user) {
	        this.user = user;
	    }

	    public Double getTotal() {
	        return total;
	    }

	    public void setTotal(Double total) {
	        this.total = total;
	    }
	}
