package fr.sup.galilee.pharmacymanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import fr.sup.galilee.pharmacymanagement.entite.Facture;

@Repository
public interface FactureRepository extends JpaRepository<Facture, Long> {
    // Ici, vous pouvez ajouter des méthodes personnalisées, par exemple pour trouver toutes les factures d'un utilisateur
    List<Facture> findByuserId(Long userId);
}