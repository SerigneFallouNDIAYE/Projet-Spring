package fr.sup.galilee.pharmacymanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.sup.galilee.pharmacymanagement.entite.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {
    // Méthodes personnalisées si nécessaire
}
