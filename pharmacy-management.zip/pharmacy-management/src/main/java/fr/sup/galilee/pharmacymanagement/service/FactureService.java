package fr.sup.galilee.pharmacymanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.sup.galilee.pharmacymanagement.entite.Facture;
import fr.sup.galilee.pharmacymanagement.repository.FactureRepository;

@Service
public class FactureService {

    private final FactureRepository factureRepository;

    @Autowired
    public FactureService(FactureRepository factureRepository) {
        this.factureRepository = factureRepository;
    }

    public List<Facture> findAllFactures() {
        return factureRepository.findAll();
    }

    public List<Facture> findFacturesByUserId(Long userId) {
      
        return factureRepository.findByuserId(userId);
    }

    public Facture saveFacture(Facture facture) {
        return factureRepository.save(facture);
    }

    
}
