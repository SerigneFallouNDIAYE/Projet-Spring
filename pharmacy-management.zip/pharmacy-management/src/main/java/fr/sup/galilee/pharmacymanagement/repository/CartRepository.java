package fr.sup.galilee.pharmacymanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import fr.sup.galilee.pharmacymanagement.entite.Cart;

import java.util.List;

public interface CartRepository extends JpaRepository<Cart, Long> {
    List<Cart> findByUtilisateur_Id(Long userId); // Utilisation de la bonne casse pour la propriété utilisateur
}
