package fr.sup.galilee.pharmacymanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fr.sup.galilee.pharmacymanagement.entite.Facture;
import fr.sup.galilee.pharmacymanagement.service.FactureService;

@RestController
@RequestMapping("/factures")
public class FactureController {

    private final FactureService factureService;

    @Autowired
    public FactureController(FactureService factureService) {
        this.factureService = factureService;
    }

    @GetMapping
    public List<Facture> getAllFactures() {
        return factureService.findAllFactures();
    }

    @GetMapping("/user/{userId}")
    public List<Facture> getFacturesByUserId(@PathVariable Long userId) {
        return factureService.findFacturesByUserId(userId);
    }

    @PostMapping
    public Facture createFacture(@RequestBody Facture facture) {
        return factureService.saveFacture(facture);
    }

 
}