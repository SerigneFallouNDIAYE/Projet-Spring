package fr.sup.galilee.pharmacymanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fr.sup.galilee.pharmacymanagement.entite.CartProduct;
import fr.sup.galilee.pharmacymanagement.service.CartProductService;

@RestController
@RequestMapping("/cart-products")
public class CartProductController {

    private final CartProductService cartProductService;

    @Autowired
    public CartProductController(CartProductService cartProductService) {
        this.cartProductService = cartProductService;
    }

    @GetMapping("/cart/{cartId}")
    public List<CartProduct> getCartProductsByCartId(@PathVariable Long cartId) {
        return cartProductService.findCartProductsByCartId(cartId);
    }

    @PostMapping
    public CartProduct addProductToCart(@RequestBody CartProduct cartProduct) {
        return cartProductService.saveCartProduct(cartProduct);
    }

   
}